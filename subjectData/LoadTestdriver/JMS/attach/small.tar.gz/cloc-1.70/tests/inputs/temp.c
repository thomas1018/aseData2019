

main() {
 int i;
}
