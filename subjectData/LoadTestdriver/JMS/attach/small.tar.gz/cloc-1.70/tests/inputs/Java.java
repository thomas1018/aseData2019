// from http://www.roesler-ac.de/wolfram/hello.htm
// Hello World in Java

import java.io.*;
class HelloWorld {
  static public void main( String args[] ) {
    System.out.println( "Hello World!" );
  }
}
